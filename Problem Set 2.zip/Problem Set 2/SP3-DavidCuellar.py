# DS 5010
# Spring 2026
# Problem Set 2
# Problem 3: Add Matrices (Functions and Loops)
# David Cuellar
import random

def creating_matrix():
    """
    This function creates and returns a 4x4 matrix with random numbers
    between 1 and 10 inclusively. This function has no parameters but it
    does return a 4x4 matrix (list of lists).
    """
    return [[random.randint(1, 10) for i in range(4)] for i in range(4)]

def displaying_matrix(matrix):
    """
    This function displays (prints) the elements in each row of a matrix.

    Parameters: 1) matrix (list of lists)

    Returns: None
    """
    for row in matrix:
        print(*row)

def adding_matrices(matrix_1, matrix_2):
    """
    This function adds two matrices together and returns the resultant matrix.

    Parameters: 1) matrix_1 (list of lists)
                2) matrix_2 (list of lists)

    Returns: 1) new_matrix (list of lists / resultant matrix)
    """
    new_matrix = []
    for i in range(len(matrix_1)):
        inner_row = []
        for j in range(len(matrix_1[0])):
            inner_row.append(matrix_1[i][j] + matrix_2[i][j])
        new_matrix.append(inner_row)
    return new_matrix

# Tests
a = [[10, 3, 3, 10], [5, 10, 10, 4], [8, 2, 6, 3], [9, 10, 8, 4]]
b = [[8, 5, 2, 7], [3, 8, 1, 3], [5, 3, 8, 4], [9, 4, 6, 10]]

expected = [
    [18, 8, 5, 17], [8, 18, 11, 7], [13, 5, 14, 7], [18, 14, 14, 14]
    ]

assert adding_matrices(a, b) == expected

def main():
    """
    This function uses the previous functions in this file and displays 
    them out neatly. 
    """
    a = creating_matrix()
    b = creating_matrix()
    
    print("Matrix A:")
    displaying_matrix(a)
    
    print('\n')

    print("Matrix B:")
    displaying_matrix(b)

    print('\n')

    c = adding_matrices(a, b)
    print("Matrix A + Matrix B:")
    displaying_matrix(c)
    
if __name__ == "__main__":
    main()