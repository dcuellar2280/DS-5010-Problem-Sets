# DS 5010
# Spring 2026
# Problem Set 2
# Problem 4: Student Grades (Iterable)
# David Cuellar

def sorted_dict(names, grades):
    """
    This function returns a sorted dictionary when pairing each
    name with their grade in descending order.

    Parameters: 1) names (list / list of students)
                2) grades (list / list of grades)

    Returns: 1) a dictionary (sorted dictionary with the names and grades)
    """
    student_dict = dict(zip(names, grades, strict=True))
    sorted_grades = sorted(
        student_dict.items(), key=lambda item: item[1], reverse=True)
    return dict(sorted_grades)

def display_dict(student_dict):
    """
    This function displays the student dictionary in enumerated order.

    Parameters: 1) student_dict (dictionary)

    Returns: None
    """
    print("Using a for-loop:")
    for index, (key, value) in enumerate(student_dict.items(), start=1):
        print(f"{index}: {key} - Grade: {value}")

def display_above_85_dict(student_dict):
    """
    This function displays the student dictionary in enumerated order
    for the student that received a grade above 85.

    Parameters: 1) student_dict (dictionary)

    Returns: None
    """
    print("Above 85 using a for-loop:")
    for index, (key, value) in enumerate(student_dict.items(), start=1):
        if value > 85:
            print(f"{index}: {key} - Grade: {value}")

def main():
    student_names = ["Alice", "Bob", "Charlie", "David", "Eve"]
    student_grades = [85, 92, 78, 95, 88]

    student_dict = sorted_dict(student_names, student_grades)

    display_dict(student_dict)
    print("\n")
    display_above_85_dict(student_dict)
    
if __name__ == "__main__":
    main()