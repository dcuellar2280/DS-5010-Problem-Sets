# DS 5010
# Spring 2026
# Problem Set 2
# Problem 1: Create a Strong Password (Coniditional Statements)
# David Cuellar

SPECIAL_CHARACTERS = ["@", "_", "!", "#", "$", "%", "^", 
                    "&", "*", "(", ")", "<", ">", "?", "/", "|",
                    "{", "}", "~", ":"]

def password_checker(password):
    """
    This function checks to see if the password satisfies the 
    requirements below. 
    - Contains at least 8 characters
    - Contains at least 1 uppercase and 1 lowercase letter
    - Contains at least 1 number
    - Contains at least 1 special character
    
    If the password satisfies all requirements,
    the function will return True and print a message that the 
    password was accepted. 
    If the given password isn't valid, the function will print
    a message telling the user what is wrong with the password 
    and return False.

    Parameters: 1) password (a string / provided by the user)

    Returns: 1) True (boolean / the password satisfies all requirements,
                    the function will return True)
             2) False (boolean / if the password doesn't satisfy any of the
                    the requirements, it will return False)
    """
    if len(password) < 8:
        print("Password must contain at least 8 characters. \n")
        return False

    has_lowercase = any(c.islower() for c in password)
    has_uppercase = any(c.isupper() for c in password)
    if not (has_lowercase and has_uppercase):
        print("Password must contain at least 1 uppercase " \
            "and 1 lowercase letter. \n")
        return False

    if not any(d.isdigit() for d in password):
        print("Password must contain at least 1 number. \n")
        return False

    if not any(ch in SPECIAL_CHARACTERS for ch in password):
        print("Password must contain at least 1 " \
            "special character. \n")
        return False
    
    print("Password accepted!")
    return True

# Tests
#assert password_checker("Hello20@") is True
#assert password_checker("Hello202") is False

def main():
    """
    This function creates a loop that asks for a valid password using
    the password_checker function. The loop will keep running
    until a valid password is entered by the user. 

    Parameters: None

    Returns: None
    """
    while True:
        user_password = input("Enter a password: ")
        if password_checker(user_password):
            break
if __name__ == "__main__":
    main()