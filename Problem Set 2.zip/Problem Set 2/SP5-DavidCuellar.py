# DS 5010
# Spring 2026
# Problem Set 2
# Problem 5: Text Files (File Handling)
# David Cuellar

def create_write_files():
    """
    This function creates 2 text files with their respective names
    and creates 5 lines of strings in each file.

    Parameters: None

    Returns: None
    """
    with open('test1.txt', "w", encoding="utf-8") as t1:
        for i in range(5):
            t1.write(f"Line {i} text in test1 text file.\n")
    
    with open('test2.txt', "w", encoding="utf-8") as t2:
        for i in range(5):
            t2.write(f"Line {i} text in test2 text file.\n")

def appends_file2():
    """
    This function reads test1 text file and appends its content
    to test2 text file.

    Parameters: None

    Returns: None
    """
    with open("test1.txt", "r", encoding="utf-8") as t1:
        content = t1.read()

    with open("test2.txt", "a", encoding="utf-8") as t2:
        t2.write(content)

def displays_file2():
    """
    This function reads test2 text file and displays its content
    line by line using a while loop.

    Parameters: None

    Returns: None
    """
    with open("test2.txt", "r", encoding="utf-8") as t2:
        line = t2.readline()
        while line:
            print(line.strip())
            line = t2.readline()

def main():
    create_write_files()
    appends_file2()
    displays_file2()

if __name__ == "__main__":
    main()