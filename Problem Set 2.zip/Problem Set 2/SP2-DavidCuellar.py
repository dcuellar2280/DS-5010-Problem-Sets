# DS 5010
# Spring 2026
# Problem Set 2
# Problem 2: Binary Search (Loops)
# David Cuellar
import random

def guessing_number():
    """
    This function generates a random whole number between 0 and 100, 
    inclusive, and prompts the user to guess a number until it's correct. 
    After each incorrect guess, the program will inform the user whether
    their guess is higher or lower than the generated number.
    Once the correct numer is guessed, the program will display the total
    number of attempts.

    Parameters: None
    
    Returns: None
    """
    target_num = random.randint(0, 100)
    tries = 0
    while True:
        user_guess = int(input("Enter a whole number between 0 and 100: "))
        tries += 1
        if user_guess == target_num:
            print("You guessed correctly!")
            print(f"It took you {tries} tries.")
            break
        elif user_guess < target_num:
            print("You guessed too low. \n")
        else:
            print("You guessed too high. \n")

# No tests for this problem

def main():
    """
    This function is just testing out the guessing_number function.
    It has no parameters or returns
    """
    guessing_number()

if __name__ == "__main__":
    main()