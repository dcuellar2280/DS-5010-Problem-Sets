# DS 5010
# Spring 2026
# Problem Set 1
# Problem 5: Dictionary Ordering
# David Cuellar

def alphabetically_dict(dictionary):
    """
    The purpose of this function is to order the provided dictionary
    alphabetically by the key values. 
    This function also prints the sorted dictionary and displays
    the names and values one per line.

    Parameter: 1) dictionary (dictionary - one I created)
    """
    sorted_dictionary = dict(sorted(dictionary.items()))
    print(sorted_dictionary)

    for key, value in sorted_dictionary.items():
        print(f"{key}: {value}")

def length_dict(dictionary):
    """
    The purpose of this function is to order the provided dictionary
    by length of key values ascending. 
    This function also prints the sorted dictionary and displays
    the names and values one per line.

    Parameter: 1) dictionary (dictionary - one I created)
    """
    sorted_dictionary = dict(sorted(dictionary.items(), key=lambda item: len(item[0])))
    print(sorted_dictionary)

    for key, value in sorted_dictionary.items():
        print(f"{key}: {value}")

def main():
    wizards = {"Harry Potter": 7, "Albus Dumbledore" : 23, "Ron Weasley" : 1}

    # 1 - Ordered alphabetically
    alphabetically_dict(wizards)

    # 2 - Ordered by length
    length_dict(wizards)

if __name__ == "__main__":
    main()