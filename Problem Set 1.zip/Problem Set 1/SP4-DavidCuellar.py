# DS 5010
# Spring 2026
# Problem Set 1
# Problem 4: List Comprehension
# David Cuellar

def main():
    
    # Part A
    b = []
    for x in 'A little knowledge is a dangerous thing.'.split():
        if len(x) <= 3:
            b.append(x)
    print(b) # Output: ['A', 'is', 'a']

    # Part A REWRITTEN using list comprehension
    b = [x for x in 'A little knowledge is a dangerous thing.'.split() if len(x) <= 3]
    print(b)

    # Part B
    c = []
    for i in range(5, 10):
        c.append([i])
    print(c) # Output: [[5], [6], [7], [8], [9]]

    # Part B REWRITTEN using list comprehension
    c = [[x] for x in range(5, 10)]
    print(c)
    
if __name__ == "__main__":
    main()