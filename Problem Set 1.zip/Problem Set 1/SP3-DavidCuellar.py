# DS 5010
# Spring 2026
# Problem Set 1
# Problem 3: List
# David Cuellar

def sorted_list(sentence):
    """
    The purpose of this function is to produce a sorted list
    of words that includes each word only once. Don't include
    punctuations.

    Parameter: 1) sentence (string - a regular sentence)
    
    Return: 1) unique_words (list - sorted list with each word from 
                            the sentence included once)
    """
    punctuation = [".", "!", "-", ")", "(", "?", ",", ";", ":"]
    for x in punctuation:
        sentence = sentence.replace(x, "")
    
    all_words = sentence.lower().split()
    unique_words = sorted(set(all_words))
    return unique_words

# Test
example = "This is a sample text. It contains words, punctuation, " \
        "and more words. This is an example."

assert sorted_list(example) == ['a', 'an', 'and', 'contains', 'example', 'is', 'it',
    'more', 'punctuation', 'sample', 'text', 'this', 'words']

def main():

    print(sorted_list(example))

if __name__ == "__main__":
    main()