# DS 5010
# Spring 2026
# Problem Set 1
# Problem 1: Temperature Conversion - Numbers
# David Cuellar

def main():
    """
    This function has no parameters or return values. The sole purpose of
    this function is to run a program that asks the user to enter a 
    Fahrenheit tempterature, and convert it to the Celsius and 
    Kelvin temperature. 
    """
    print("This program converts temperature in degrees Fahrenheit to " \
    "degrees Celsius and degrees Kelvin.")

    user_input = float(input(
        "Please enter an integer number of degrees Fahrenheit: "))
    
    celsius_temp = (user_input - 32) * (5 / 9)
    kelvin_temp = (user_input - 32) * (5 / 9) + 273.15

    print(f"{int(user_input)} degrees Fahrenheit equals to " \
        f"{celsius_temp:.2f} degrees Celsius.")

    print(f"{int(user_input)} degrees Fahrenheit equals to " \
        f"{kelvin_temp:.2f} degrees Kelvin.")

if __name__ == "__main__":
    main()
