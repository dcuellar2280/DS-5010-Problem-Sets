# DS 5010
# Spring 2026
# Problem Set 1
# Problem 2: String Indexing
# David Cuellar

#(1) Phone Number
def phone_edit(number):
    """
    The purpose of this function is to create a new string that contains
    a phone number from the parameter with the dashes.

    Parameter: 1) number (a string - a phone number without dashes)
    Return: 1) new_number (a string - a new string with the phone number but 
                            with the dashes)

    """
    new_number = number[0:3] + "-" + number[3:6] + "-" + number[6:]
    return new_number

#(2) Northeastern University
def schoolname_edit(name):
    """
    The purpose of this function is to take create a new string
    that contains the first and last character of the name entered
    in uppercase.

    Parameter: 1) name (a string - school name for this problem)
    Return: 1) new_name (a string - capitalized first and last character)

    """
    new_name = (name[0] + name[-1]).upper()
    return new_name

def blackboard_edit(word):
    """
    The purpose of this function is to create a new string that capitalizes
    the two letters after the first 'a' from the word provided.

    Parameter: 1) word (a string - 'blackboard' for this problem)
    Return: 1) new_word (a string - same word but with capitalized letters)

    """
    a_position = word.find("a")
    two_letters = (word[a_position + 1: a_position + 3]).upper()
    new_word = word[0:a_position + 1] + two_letters + word[a_position + 3:]
    return new_word

# Tests
assert phone_edit("9871233456") == "987-123-3456"
assert schoolname_edit("Northeastern University") == "NY"
assert blackboard_edit("blackboard") == "blaCKboard"

#(3) Blackboard
def main():
    #(1) Phone Number
    NUM = "9871233456"
    print(phone_edit(NUM))

    #(2) Northeastern University
    school_name = "Northeastern University"
    print(schoolname_edit(school_name))

    #(3) Blackboard
    word = "blackboard"
    print(blackboard_edit(word))

if __name__ == "__main__":
    main()
